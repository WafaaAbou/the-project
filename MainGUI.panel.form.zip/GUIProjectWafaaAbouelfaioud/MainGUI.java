import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;

public class MainGUI extends JFrame {
    private JTextField textField1;
    private JTextField textField2;
    private JTextArea decriptionIsShownHereTextArea;
    private JTextField textField3;
    private JTextField textField4;
    private JButton pileButton;
    private JButton unpileButton;
    private JButton showContainerDescriptionButton;
    private JTextField columnNumberTextField;
    private JButton numberOfContainersButton;
    private JTextArea descriptionIsShownThereTextArea;
    private JComboBox<String> comboBox2;
    private JTextField putNumberHereTextField;
    private JComboBox comboBox1;
    private JRadioButton a1RadioButton;
    private JRadioButton a2RadioButton;
    private JRadioButton a3RadioButton;
    private JTextArea textArea2;
    private JCheckBox checkBox1;
    private JPanel mainPanel;

    public MainGUI () {
        setTitle("WELCOME");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setContentPane(mainPanel);




        pileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int IDNumber = Integer.parseInt(textField1.getText());
                int Weight = Integer.parseInt(textField2.getText());
                int NumberOfContainers = Integer.parseInt(numberOfContainersButton.getText());
                int Number = Integer.parseInt(columnNumberTextField.getText());

            }
        });
        checkBox1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkBox1.setSelected(true);
            }
        });

       /* DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>();
        model.addElement("AFG - Afghanistan");
        model.addElement("ALB - Albania");
        model.addElement("DZA - Algeria");
// add more countries here
        comboBox2.setModel(model);*/


        comboBox2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCountry = (String) comboBox2.getSelectedItem();

            }
        });

    }}



