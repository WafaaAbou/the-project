public class ThePort {

    static TheHub hub1 = new TheHub();
    static TheHub hub2 = new TheHub();
    static TheHub hub3 = new TheHub();

    public ThePort(){

    }
}
